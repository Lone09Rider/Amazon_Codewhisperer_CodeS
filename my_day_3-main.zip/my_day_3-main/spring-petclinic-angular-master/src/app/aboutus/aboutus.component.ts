import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent {
  // Create a variable with Shrutiranjan Jena
  fname = 'Shrutiranjan';
  lname = 'Jena';
}
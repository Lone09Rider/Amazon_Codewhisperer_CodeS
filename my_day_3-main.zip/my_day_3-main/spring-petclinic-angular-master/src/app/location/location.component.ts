import { Component } from '@angular/core';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent {
  ngOnInit() {
  }
  //create an oninit method for onSubmit the form in pet-allocation.component.html

  onSubmit(){
    alert("Form Submitted");
  }
}

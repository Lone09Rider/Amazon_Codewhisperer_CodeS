import { Component } from '@angular/core';

@Component({
  selector: 'app-helppage',
  templateUrl: './helppage.component.html',
  styleUrls: ['./helppage.component.css']
})
export class HelppageComponent {

  // Ceate variable for storing name
  title = "Regarding Anhy Help Contact Us";

  // Ceate variable for storing name
  name = "Shrutiranjna Jena";

  // Ceate variable for storing contact
  contact = "9677-XXXX-32";

  // Ceate variable for storing gmail
  gmail = "sr009j@gmail.com";


  // Generate some things to display in help page
  things = [
    {
      name: "Shrutiranjna Jena",
      contact: "9677-XXXX-32",
      gmail: "sr009j@gmail.com"
    }
  ]

}
package com.demo.jgitdemo;

import java.io.File;

import org.eclipse.jgit.api.CloneCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;

public class CloneProcess {

	public static void main(String[] args) {

		// // To Clone a repository
		
		String repositoryURL = "https://github.com/Lone09Rider/Oracle_PL_SQL"; 
        String destinationPath = "C:\\Users\\VMAdmin\\Downloads\\JGit Work";

        try {
            CloneCommand cloneCommand = Git.cloneRepository()
                    .setURI(repositoryURL)
                    .setDirectory(new File(destinationPath));

            Git git = cloneCommand.call();
            git.close();

            System.out.println("Repository cloned successfully!");
        } catch (GitAPIException e) {
            e.printStackTrace();
            System.err.println("Error cloning repository: " + e.getMessage());
        }
		
	}
}
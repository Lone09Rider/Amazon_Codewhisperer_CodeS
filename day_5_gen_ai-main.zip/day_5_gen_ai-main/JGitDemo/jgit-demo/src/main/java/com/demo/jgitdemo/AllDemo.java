package com.demo.jgitdemo;

import java.io.File;
import java.io.IOException;

import org.eclipse.jgit.api.AddCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullCommand;
import org.eclipse.jgit.api.PushCommand;
import org.eclipse.jgit.api.errors.CanceledException;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.InvalidConfigurationException;
import org.eclipse.jgit.api.errors.InvalidRemoteException;
import org.eclipse.jgit.api.errors.NoHeadException;
import org.eclipse.jgit.api.errors.RefNotAdvertisedException;
import org.eclipse.jgit.api.errors.RefNotFoundException;
import org.eclipse.jgit.api.errors.TransportException;
import org.eclipse.jgit.api.errors.WrongRepositoryStateException;
import org.eclipse.jgit.transport.TransportHttp;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

public class AllDemo {
    public static void main(String[] args) throws IOException, WrongRepositoryStateException, InvalidConfigurationException, InvalidRemoteException, CanceledException, RefNotFoundException, RefNotAdvertisedException, NoHeadException, TransportException, GitAPIException {

    // Git git = Git.init().setDirectory(new File("C:\\Users\\VMAdmin\\Downloads\\JGit Work")).call();

        // How to clone an existing repository

    //    Git git = Git.cloneRepository()
    //            .setURI("https://github.com/ramanujds/jgit-example-repo.git")
    //            .setDirectory(new File("C:\\Users\\VMAdmin\\Downloads\\JGit Work"))
    //            .call();
    // How to add changes?

    //    Git git = Git.open(new File("C:\\Users\\VMAdmin\\Downloads\\JGit Work"));

    //    AddCommand add = git.add();

    //    add.addFilepattern("README.md").call();
//
//
//        // How to commit?
//
//        CommitCommand commit = git.commit();
//
//        commit.setAll(true).setMessage("Test commit").call();
//
//        // How to push?
//
//        PushCommand push = git.push();
//        // Provide the credentials
//
//        push.setCredentialsProvider(new UsernamePasswordCredentialsProvider("username","password"));
//
//        push.call();


        // How to pull changes

        Git git = Git.open(new File("C:\\Users\\VMAdmin\\Downloads\\JGit Work"));

        PullCommand pullCommand = git.pull();

        pullCommand.call();
    }
}

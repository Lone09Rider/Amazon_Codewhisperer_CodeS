package com.sql_dynamic_queries.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sql_dynamic_queries.demo.Entity.PetTreatment;
import com.sql_dynamic_queries.demo.service.PetTreatmentService;

import java.util.List;

@RestController
@RequestMapping("/pet-treatments")
public class PetTreatmentController {

    @Autowired
    private PetTreatmentService petTreatmentService;

    @GetMapping("/byOwner")
    public List<PetTreatment> getTreatmentsByOwner(@RequestParam String owner) {
        return petTreatmentService.findTreatmentsByOwner(owner);
    }

    @GetMapping("/countByName")
    public int countTreatmentsByName(@RequestParam String name) {
        return petTreatmentService.countTreatmentsWithNameLike(name);
    }
}

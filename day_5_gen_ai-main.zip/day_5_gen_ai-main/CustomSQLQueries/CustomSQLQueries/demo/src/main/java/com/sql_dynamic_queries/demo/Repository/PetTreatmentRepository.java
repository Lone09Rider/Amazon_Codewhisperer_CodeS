package com.sql_dynamic_queries.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.sql_dynamic_queries.demo.Entity.PetTreatment;

public interface PetTreatmentRepository extends CrudRepository<PetTreatment, Integer> {
    
    @Query("SELECT p FROM PetTreatment p WHERE p.owner = :owner")
    List<PetTreatment> findTreatmentsByOwner(@Param("owner") String owner);

    @Query(value = "SELECT COUNT(*) FROM pet_treatment WHERE name LIKE %:name%", nativeQuery = true)
    int countTreatmentsWithNameLike(@Param("name") String name);

}

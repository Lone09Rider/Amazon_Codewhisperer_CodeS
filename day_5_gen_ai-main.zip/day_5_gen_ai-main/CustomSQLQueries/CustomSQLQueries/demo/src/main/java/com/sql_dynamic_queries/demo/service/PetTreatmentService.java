package com.sql_dynamic_queries.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sql_dynamic_queries.demo.Entity.PetTreatment;
import com.sql_dynamic_queries.demo.Repository.PetTreatmentRepository;

import java.util.List;

@Service
public class PetTreatmentService {
    @Autowired
    private PetTreatmentRepository petTreatmentRepository;

    public List<PetTreatment> findTreatmentsByOwner(String owner) {
        return petTreatmentRepository.findTreatmentsByOwner(owner);
    }

    public int countTreatmentsWithNameLike(String name) {
        return petTreatmentRepository.countTreatmentsWithNameLike(name);
    }
}

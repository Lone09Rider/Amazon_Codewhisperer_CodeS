package com.myquack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myquack.entity.Car;
import com.myquack.repo.CarRepo;
import com.myquack.service.CarServicewithIMPL;
import java.util.List;

@RestController
@RequestMapping("/cars")
public class CarController {

    @Autowired
    private CarServicewithIMPL carService;

    @Autowired
    private CarRepo repo;

    // get all cars
    @GetMapping
    public List<Car> getAllCars() {
        return carService.getAllCars();
    }
    
    @PostMapping
    public Car addCar(Car car) {
        return carService.addCar(car);
    }

    @PutMapping("/{id}")
    public Car updateCar(@PathVariable("id") int id, Car car) {
        return carService.updateCar(id, car);
    }

    @DeleteMapping("/{id}")
    public void deleteCar(@PathVariable("id") int id) {
        carService.deleteCar(id);
    }
}

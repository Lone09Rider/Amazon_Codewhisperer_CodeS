package com.myquack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myquack.entity.Car;
import com.myquack.repo.CarRepo;
import java.util.List;

@Service
public class CarServicewithIMPL {
    @Autowired
    private CarRepo repo;

    // add a car
    public Car addCar(Car car) {
        return repo.save(car);
    }

    // get all cars
    public List<Car> getAllCars() {
        return repo.findAll();
    }

    // update a car
    public Car updateCar(int id, Car newCar) {
        Car car = new Car();
        car.setId(id);
        car.setName(newCar.getName());
        car.setModel(newCar.getModel());
        
        return repo.save(car);
    }
    
    // delete a car
    public void deleteCar(int id) {
        repo.deleteById(id);
    }

}

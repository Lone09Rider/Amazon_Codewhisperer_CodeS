package com.myquack.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myquack.entity.Car;

public interface CarRepo extends JpaRepository<Car,Integer> {
    
}

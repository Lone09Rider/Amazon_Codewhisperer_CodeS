package com.clinic.pettreatment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.clinic.pettreatment.entity.PetTreatment;
import com.clinic.pettreatment.service.PetTreatmentService;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/petTreat")
public class PetTreatmentController {
    @Autowired
    private PetTreatmentService petTreatmentService;


    @GetMapping
    public List<PetTreatment> getAllPetTreatments() {
        return petTreatmentService.getAllPetTreatments();
    }

    @GetMapping("/{id}")
    public PetTreatment getPetTreatmentById(@PathVariable Long id) {
        return petTreatmentService.getPetTreatmentById(id);
    }

    @PostMapping
    public PetTreatment createPetTreatment(@RequestBody PetTreatment petTreatment) {
        return petTreatmentService.savePetTreatment(petTreatment);
    }

    @PutMapping("/{id}")
    public PetTreatment updatePetTreatment(@PathVariable Long id, @RequestBody PetTreatment petTreatment) {
        petTreatment.setId(id);
        return petTreatmentService.savePetTreatment(petTreatment);
    }

    @DeleteMapping("/{id}")
    public void deletePetTreatment(@PathVariable Long id) {
        petTreatmentService.deletePetTreatment(id);
    }

    @GetMapping("/async")
    public CompletableFuture<List<PetTreatment>> getAllPetTreatmentsAsync() throws InterruptedException {
        return petTreatmentService.getAllPetTreatmentsAsync();
    }

    @GetMapping("/async/{id}")
    public CompletableFuture<Optional<PetTreatment>> getPetTreatmentByIdAsync(@PathVariable Long id) {
        return petTreatmentService.getPetTreatmentByIdAsync(id);
    }

    @PostMapping("/async")
    public CompletableFuture<PetTreatment> createPetTreatmentAsync(@RequestBody PetTreatment petTreatment) {
        return petTreatmentService.savePetTreatmentAsync(petTreatment);
    }

    @PutMapping("/async/{id}")
    public CompletableFuture<PetTreatment> updatePetTreatmentAsync(@PathVariable Long id, @RequestBody PetTreatment petTreatment) {
        petTreatment.setId(id);
        return petTreatmentService.savePetTreatmentAsync(petTreatment);
    }

    @DeleteMapping("/async/{id}")
    public CompletableFuture<Void> deletePetTreatmentAsync(@PathVariable Long id) {
        return petTreatmentService.deletePetTreatmentAsync(id);
    }
}


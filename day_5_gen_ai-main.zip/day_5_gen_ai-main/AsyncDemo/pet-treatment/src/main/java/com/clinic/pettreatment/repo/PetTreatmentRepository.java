package com.clinic.pettreatment.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.clinic.pettreatment.entity.PetTreatment;

public interface PetTreatmentRepository extends JpaRepository<PetTreatment, Long> {
    
}

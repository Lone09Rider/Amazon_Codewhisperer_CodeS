package com.clinic.pettreatment.service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.clinic.pettreatment.entity.PetTreatment;
import com.clinic.pettreatment.repo.PetTreatmentRepository;

@Service
public class PetTreatmentService {
    @Autowired
    private PetTreatmentRepository petTreatmentRepository;

    public List<PetTreatment> getAllPetTreatments() {
        return petTreatmentRepository.findAll();
    }

    public PetTreatment getPetTreatmentById(Long id) {
        return petTreatmentRepository.findById(id).get();
    }

    public PetTreatment savePetTreatment(PetTreatment petTreatment) {
        return petTreatmentRepository.save(petTreatment);
    }

    public void deletePetTreatment(Long id) {
        petTreatmentRepository.deleteById(id);
    }

    @Async
    public CompletableFuture<List<PetTreatment>> getAllPetTreatmentsAsync() throws InterruptedException {
        List<PetTreatment> treatments = petTreatmentRepository.findAll();
        Thread.sleep(6000);
        return CompletableFuture.completedFuture(treatments);
    }
    
     @Async
    public CompletableFuture<Optional<PetTreatment>> getPetTreatmentByIdAsync(Long id) {
        Optional<PetTreatment> treatment = petTreatmentRepository.findById(id);
        return CompletableFuture.completedFuture(treatment);
    }

    @Async
    public CompletableFuture<PetTreatment> savePetTreatmentAsync(PetTreatment petTreatment) {
        PetTreatment savedTreatment = petTreatmentRepository.save(petTreatment);
        return CompletableFuture.completedFuture(savedTreatment);
    }

    @Async
    public CompletableFuture<Void> deletePetTreatmentAsync(Long id) {
        petTreatmentRepository.deleteById(id);
        return CompletableFuture.completedFuture(null);
    }
}

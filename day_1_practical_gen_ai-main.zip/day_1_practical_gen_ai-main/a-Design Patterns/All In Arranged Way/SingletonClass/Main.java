package SingletonClass;

// Implement Singleton Class here
class Main {
    public static void main(String[] args) {
        SingletonClass instance = SingletonClass.getInstance();
        SingletonClass instance2 = SingletonClass.getInstance();
        System.out.println(instance == instance2);
        System.out.println(instance.hashCode());
        System.out.println(instance2.hashCode());
        System.out.println(instance.equals(instance2));
    }
}
package PetClininc_Builder;

public class Main {
    // Implement the Builder pattern to create a Pet object
    public static void main(String[] args) {
        Pet pet = new PetBuilder("Jhonny", 3, "Labrador", "Brown", "Dog").build();
        System.out.println(pet);
    }
}

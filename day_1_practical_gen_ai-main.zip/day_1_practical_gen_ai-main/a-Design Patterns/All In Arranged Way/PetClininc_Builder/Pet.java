package PetClininc_Builder;

// Create pet class with name string, age int, breed string, color string, type string


public class Pet {
    private String name;
    private int age;
    private String breed;
    private String color;
    private String type;
    
    public Pet() {
    }

    public Pet(String name, int age, String breed, String color, String type) {
        this.name = name;
        this.age = age;
        this.breed = breed;
        this.color = color;
        this.type = type;
    }

    // ToString 
    public String toString() {
        return "Pet [name=" + name + ", age=" + age + ", breed=" + breed + ", color=" + color + ", type=" + type + "]";
    }

    // Generate Getters and Setters for all variables

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getBreed() {
        return breed;
    }
    public void setBreed(String breed) {
        this.breed = breed;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {   
        this.color = color;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}



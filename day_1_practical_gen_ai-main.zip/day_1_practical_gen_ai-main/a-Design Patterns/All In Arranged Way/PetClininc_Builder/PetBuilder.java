package PetClininc_Builder;

// Create a Builder class for the Pet class

public class PetBuilder {
    private String name;
    private int age;
    private String breed;
    private String color;
    private String type;

    public PetBuilder(String name, int age, String breed, String color, String type) {
        this.name = name;
        this.age = age;
        this.breed = breed;
        this.color = color;
        this.type = type;
    }

    public Pet build() {
        return new Pet(name, age, breed, color, type);
    }
}
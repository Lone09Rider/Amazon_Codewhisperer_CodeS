package PrototypeDemo;

public class Main {
    public static void main(String[] args) {
        Car car = new Car();
        car.setModel("Carrera");
        System.out.println(car.getModel());
        Car car2 = new Car();
        car2.setModel("Commodore");
        System.out.println(car2.getModel());
    }
}

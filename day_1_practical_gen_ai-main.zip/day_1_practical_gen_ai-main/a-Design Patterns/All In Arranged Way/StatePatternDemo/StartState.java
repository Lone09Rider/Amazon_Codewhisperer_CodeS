package StatePatternDemo;

// Implement State Here 

public class StartState implements State {
    public void doAction() {
        System.out.println("Player is in start state");
    }
} 
    


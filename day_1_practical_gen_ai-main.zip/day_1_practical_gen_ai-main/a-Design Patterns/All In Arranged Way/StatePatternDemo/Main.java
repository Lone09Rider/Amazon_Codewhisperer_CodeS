package StatePatternDemo;

public class Main {
    // Implement State Pattern using Player
    public static void main(String[] args) {
        Player player = new Player();
        player.setState(new StartState());
        player.getState().doAction();
    }

}

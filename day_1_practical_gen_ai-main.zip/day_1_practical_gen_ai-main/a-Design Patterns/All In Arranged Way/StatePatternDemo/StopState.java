package StatePatternDemo;

// Implement State Here 

class StopState implements State {
    public void doAction() {
        System.out.println("Player is in stop state");
    }
}


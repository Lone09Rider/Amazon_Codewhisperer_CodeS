package StatePatternDemo;

// Create interface State with doAction();

public interface State {
    public void doAction();
}

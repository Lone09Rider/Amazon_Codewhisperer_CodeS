package StatePatternDemo;

// Create a Player Class with State state as variable and do getters and setters

public class Player {
	
	private State state;
	
	public Player() {
		state = null;
	}
	
	public State getState() {
		return state;
	}
	
	public void setState(State state) {
		this.state = state;
	}
	
}
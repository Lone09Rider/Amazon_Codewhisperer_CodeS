package AbstractFatoryDemo;

// Create a car class with the following attributes: make, model, year, color, and price.
public class Car {
    CarCompany carCompany;
    String model;
    int year;

    Car(CarCompany carCompany, String model, int year) {
        this.carCompany = carCompany;
        this.model = model;
        this.year = year;
    }

    // Generate getters and setters
    public CarCompany getCarCompany() {
        return carCompany;
    }
    public void setCarCompany(CarCompany carCompany) {
        this.carCompany = carCompany;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }

    // Generate empty Constructor
    public Car() {
    }

    // Generate toString
    public String toString() {
        return "Car [carCompany=" + carCompany + ", model=" + model + ", year=" + year + "]";
    }

}
package AbstractFatoryDemo;

// Create CarCompany enum with 3 models
public enum CarCompany {
    BMW,
    AUDI,
    MERCEDES
}
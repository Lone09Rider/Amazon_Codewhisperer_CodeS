package AbstractFatoryDemo;

public class AbstractFactoryImpl {
    public static void main(String[] args) {
        Car car = AbstractFactoryDemo.getCar(CarCompany.BMW, "X5", 2020);
        System.out.println(car);
        Car car2 = AbstractFactoryDemo.getCar(CarCompany.AUDI, "A3", 2019);
        System.out.println(car2);
        Car car3 = AbstractFactoryDemo.getCar(CarCompany.MERCEDES, "C-Class", 2018);
        System.out.println(car3);
    }
}

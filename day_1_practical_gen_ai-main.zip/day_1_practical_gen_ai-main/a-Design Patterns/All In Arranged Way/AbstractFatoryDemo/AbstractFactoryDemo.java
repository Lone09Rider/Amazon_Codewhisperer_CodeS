package AbstractFatoryDemo;

// Use enums CarCompany with Car and implement abstract factory
public class AbstractFactoryDemo {
    public static Car getCar(CarCompany carCompany, String model, int year) {
        switch (carCompany) {
            case BMW:
                return new Car(CarCompany.BMW, model, year);
            case AUDI:
                return new Car(CarCompany.AUDI, model, year);
            case MERCEDES:
                return new Car(CarCompany.MERCEDES, model, year);
            default:
                return null;
        }
    }
}
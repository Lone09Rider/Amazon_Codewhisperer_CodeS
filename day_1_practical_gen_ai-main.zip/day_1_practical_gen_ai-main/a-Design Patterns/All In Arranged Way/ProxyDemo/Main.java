package ProxyDemo;

// Implement Proxy Design Pattern

public class Main {
    public static void main(String[] args) {
        Car car = new CarProxy(new CarImpl());
        car.drive();
    }
}

package ProxyDemo;

// Create CarProxy class implement Car to show proxy method

public class CarProxy implements Car {
	private Car car;
	
	public CarProxy(Car car) {
		this.car = car;
	}
	
	@Override
	public void drive() {
		System.out.println("Before driving");
		car.drive();
		System.out.println("After driving");
	}
}

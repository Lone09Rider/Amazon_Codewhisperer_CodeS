package ProxyDemo;

// Craete car interafce with drive method

public interface Car {
    public void drive();
}

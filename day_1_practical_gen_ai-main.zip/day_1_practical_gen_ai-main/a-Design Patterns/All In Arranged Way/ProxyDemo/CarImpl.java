package ProxyDemo;

// Implement Car to this class

public class CarImpl implements Car {
    public void drive() {
        System.out.println("Driving");
    }
}

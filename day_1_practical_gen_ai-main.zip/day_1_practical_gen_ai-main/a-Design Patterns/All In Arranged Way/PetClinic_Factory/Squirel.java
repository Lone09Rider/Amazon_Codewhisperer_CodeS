package PetClinic_Factory;

// create Squirel Class Implementing Pet Interface

public class Squirel implements Pet {
	
	@Override
	public void speak() {
		System.out.println("Squirel Speak");
	}

}
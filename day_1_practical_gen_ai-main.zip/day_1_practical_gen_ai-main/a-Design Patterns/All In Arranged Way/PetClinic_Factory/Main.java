package PetClinic_Factory;

/* Create Factory method pattern to get the Pet object in PetClinic application */

class Main {

    public Pet getPet(String petType) {
        if (petType.equals("Dog")) {
            return new Dog();
        } else if (petType.equals("Cat")) {
            return new Cat();
        } else if (petType.equals("squirel")) {
            return new Squirel();
        } else {
            throw new IllegalArgumentException("Unknown pet type");
        }
    }
}
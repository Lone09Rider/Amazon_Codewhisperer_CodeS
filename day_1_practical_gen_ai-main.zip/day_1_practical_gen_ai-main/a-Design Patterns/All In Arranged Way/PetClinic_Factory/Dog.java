package PetClinic_Factory;

// create Dog Class Implementing Pet Interface

public class Dog implements Pet {

	public void speak() {
		System.out.println("Woof");
	}

}
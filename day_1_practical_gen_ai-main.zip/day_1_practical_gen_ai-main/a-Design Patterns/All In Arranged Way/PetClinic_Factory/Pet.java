package PetClinic_Factory;

// Create Pet Interface

public interface Pet {
    public void speak();
}

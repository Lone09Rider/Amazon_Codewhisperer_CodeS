package PetClinic_Factory;

// create Cat Class Implementing Pet Interface

class Cat implements Pet {
    public void speak() {
        System.out.println("Meow");
    }
}
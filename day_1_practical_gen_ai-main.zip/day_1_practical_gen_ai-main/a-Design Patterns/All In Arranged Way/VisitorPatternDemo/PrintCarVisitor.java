package VisitorPatternDemo;

// Implement CarVisitor Here

public class PrintCarVisitor implements CarVisitor {

    @Override
    public void visit(Car car) {
        System.out.println(car.getState() + " " + car.getModel());
    }
} 
    


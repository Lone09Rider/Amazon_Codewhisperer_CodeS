package VisitorPatternDemo;

// Create CarVisitor interface with visit(Car car);

public interface CarVisitor {
    void visit(Car car);
}

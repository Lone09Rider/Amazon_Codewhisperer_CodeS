package VisitorPatternDemo;

// Implement Visitor Pattern using car and carVisitor
public class Main {
    public static void main(String[] args) {
        Car car = new Car("Toyota", "Camry");
        CarVisitor visitor = new PrintCarVisitor();
        visitor.visit(car);
    }
}
package VisitorPatternDemo;

// Car class with state and model

public class Car {
    private String state;
	private String model;
	
	public Car(String state, String model) {
		this.state = state;
		this.model = model;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}	
	
	public String toString() {
		return "Car [state=" + state + ", model=" + model + "]";
	}	
	
}
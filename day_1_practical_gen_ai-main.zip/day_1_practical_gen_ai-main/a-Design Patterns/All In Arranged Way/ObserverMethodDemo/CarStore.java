package ObserverMethodDemo;

import java.util.ArrayList;
public class CarStore {

    // Craete ArrayList of Cars
    private ArrayList<Car> cars = new ArrayList<>();
    
    // Add Car to ArrayList
    public void addCar(Car car) {
        cars.add(car);
    }

    // Update all cars
    public void updateCars() {
        for (Car car : cars) {
            car.drive();
        }
    }
}

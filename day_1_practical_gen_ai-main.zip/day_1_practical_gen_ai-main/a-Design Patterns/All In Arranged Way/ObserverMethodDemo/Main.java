package ObserverMethodDemo;

public class Main {
    // Implementing the Observer Pattern from car, enum, carstore
    public static void main(String[] args) {
        CarStore carStore = new CarStore();
        carStore.addCar(new BMW());
        carStore.addCar(new Audi());

        carStore.updateCars();
    }
}

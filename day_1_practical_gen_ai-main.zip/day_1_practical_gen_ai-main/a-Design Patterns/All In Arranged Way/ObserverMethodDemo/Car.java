package ObserverMethodDemo;

// Create Car Interface

public interface Car {
    void drive();
}


package ObserverMethodDemo;

// Implement Car Interface Here

public class BMW implements Car {
    @Override
	public void drive() {
		System.out.println("Driving BMW");
	}
}
// Show all datatypes persent in java using codes

class Datatype {
    public static void main(String[] args) {
        // Give one example of each by assigning it to a variable and then print.
        int a = 10;
        float b = 10.5f;
        double c = 10.5;
        char d = 'a';
        boolean e = true; 
        String f = "Hello World";

        // print all now
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);

    }

}
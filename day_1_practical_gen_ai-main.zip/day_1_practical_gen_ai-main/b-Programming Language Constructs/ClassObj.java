// Example for class object creation with car 

public class ClassObj {
    static class Car {
        int yearModel;
        String make;
        int speed;
        
        void accelerate() {
            speed += 5;
        }
        
        void brake() {
            speed -= 5;
        }
    }

    public static void main(String[] args) {
		Car myCar = new Car();
		myCar.yearModel = 2018;
		myCar.make = "Toyota";
		myCar.speed = 120;
		
		System.out.println("Year: " + myCar.yearModel);
		System.out.println("Make: " + myCar.make);
		System.out.println("Speed: " + myCar.speed);
		
		myCar.accelerate();
		System.out.println("Speed: " + myCar.speed);
		
		myCar.brake();
		System.out.println("Speed: " + myCar.speed);
	}
}
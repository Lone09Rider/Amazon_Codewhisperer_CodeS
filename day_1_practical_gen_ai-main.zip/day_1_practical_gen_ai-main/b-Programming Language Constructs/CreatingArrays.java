import java.util.ArrayList;
public class CreatingArrays {
   public static void main(String[] args) {
        // Create a one Dimentional Array and print
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);
        }
        System.out.println("-------------------------------------------------");
        // Create a Two Dimentional Array and print
        int[][] matrix = {
                {1, 2, 3},
                {4, 5, 6}
            };

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.println(matrix[i][j]);
            }
        }
        
        System.out.println("-------------------------------------------------");
        // Create a one Dimentional Array using ArrayList and print
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);

        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        System.out.println("-------------------------------------------------");

        // Create a Two Dimentional Array and print
        ArrayList<ArrayList<Integer>> matrix2 = new ArrayList<>();
        ArrayList<Integer> list2 = new ArrayList<>();
        list2.add(1);
        list2.add(2);
        list2.add(3);
        matrix2.add(list2);

        ArrayList<Integer> list3 = new ArrayList<>();
        list3.add(4);
        list3.add(5);
        list3.add(6);
        matrix2.add(list3);

        for (int i = 0; i < matrix2.size(); i++) {
            for (int j = 0; j < matrix2.get(i).size(); j++) {
                System.out.println(matrix2.get(i).get(j));
            }
        }
        System.out.println(matrix2);
        System.out.println("-------------------------------------------------");


    }
    
}


// Create an array with random nums and use bubble sort to sort and store in new variable


public class someArrayMethod {
    public static void main(String[] args) {
        int[] arr = {5,3,2,1,4};
        int[] sorted = bubbleSort(arr);
        for(int i : sorted) {
            System.out.println(i);
        }
    }

    public static int[] bubbleSort(int[] arr) {
        for(int i = 0; i < arr.length; i++) {
            for(int j = 0; j < arr.length-1; j++) {
                if(arr[j] > arr[j+1]) {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
        return arr;
    }
}
// create code for multilevel inheritance using vehicle and car models Bugati and Lembo

class MultilevelInheritance{

        
    static class Vehicle{
        void run(){
            System.out.println("Vehicle is running");
        }
    }

    static class Bugati extends Vehicle{
        void run(){
            System.out.println("Bugati is running");
        }
    }

    static class Lembo extends Bugati{
        void run(){
            System.out.println("Lembo is running");
        }
    }


    public static void main(String[] args) {
        Bugati b = new Bugati();
        b.run();
        System.out.println("====================================");
       Vehicle v = new Vehicle();
       v.run();
        System.out.println("====================================");
       Bugati b1 = new Bugati();
       b1.run();
       System.out.println("====================================");
       Lembo l1 = new Lembo();
       l1.run();
    }
}

// create code for single level inheritance

class A
{
	int a;
	void display()
	{
		System.out.println("a="+a);
	}
}

// implemet class b extending a

class B extends A
{
	int b;
	void display()
	{
		System.out.println("b="+b);
	}
}

// show in main method of SingleInheritance

class SingleInheritance{
    public static void main(String[] args) {
        B b = new B();
        b.a = 10;
        b.b = 20;
        b.display(); // a=10 b=20
        A a = new A();
        a.a = 30;
        a.display(); // a=30
        B b1 = new B();
        b1.a = 40;
        b1.b = 50;
        b1.display(); // a=40 b=50
        A a1 = new A();
        a1.a = 60;
        a1.display(); // a=60
        B b2 = new B();
        b2.a = 70;
        b2.b = 80;
        b2.display(); // a=70 b=80
        A a2 = new A();
        a2.a = 90;
        a2.display(); // a=90
        B b3 = new B();
        b3.a = 100;
        b3.b = 110;
        b3.display(); // a=100 b=110
    }
}

// Create 2 classes: one for the person and one for the car. 
// The person class should have a name and an age. 


class Person {
    String name;
    int age;
    // Create a method to display the values.

    void printDetails() {
        System.out.println("Name: " + name + " Age: " + age);
    }
}


// The car class should have a make, model, and year. 

class Car {
    String make;
    String model;
    int year;

    // Create a method to display the values.
    void printDetails() {
        System.out.println("Make: " + make + " Model: " + model + " Year: " + year);
    }
}

// Create an instance of the person class and an instance of the car class. 

public class ClassObject {
    public static void main(String[] args) {
        Person person = new Person();
        Car car = new Car();

        person.name = "John Doe";
        person.age = 30;

        car.make = "Toyota";
        car.model = "Camry";
        car.year = 2020;

        person.printDetails(); // p
        car.printDetails(); // c
    }
}


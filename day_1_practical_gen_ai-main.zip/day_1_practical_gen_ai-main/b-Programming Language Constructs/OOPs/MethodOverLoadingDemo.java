// Give Method Overloading Demo using Person

class MethodOverLoadingDemo{  
    static class Person{  
        String name;  
        int age;
        int my_class;
          
        Person(String name,int age){  
        this.name=name;  
        this.age=age;  
        }  
    
        Person(String name,int age,int my_class){  
            this.name=name;  
            this.age=age;  
            this.my_class=my_class;
        }
    }
    
    public static void main(String args[]){  
        Person p1=new Person("John",25);
        Person p2=new Person("Smith",30);
        System.out.println(p1.name+" "+p1.age);
        System.out.println(p2.name+" "+p2.age);

        System.out.println("====================================");

        Person p3=new Person("John",25,10);
        Person p4=new Person("Smith",30,11);
        System.out.println(p3.name+" "+p3.age+" "+p3.my_class);
        System.out.println(p4.name+" "+p4.age+" "+p4.my_class);

    }   
}
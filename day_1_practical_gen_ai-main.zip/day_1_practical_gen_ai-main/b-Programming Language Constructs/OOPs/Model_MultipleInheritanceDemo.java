// Implement Multiple Inheritance using Interfaces, take person example

class Model_MultipleInheritanceDemo {
    static interface Person {
        void eat();
    }
    
    static interface Employee {
        void work();
    }
    
    static interface Teacher extends Person, Employee {
        void teach();
    }
    
    static class TeacherImpl implements Teacher {
        public void eat() {
            System.out.println("Teacher is eating");
        }
    
        public void work() {
            System.out.println("Teacher is working");
        }
    
        public void teach() {
            System.out.println("Teacher is teaching");
        }
    }

    public static void main(String[] args) {
        Teacher teacher = new TeacherImpl();
        teacher.eat();
        teacher.work();
        teacher.teach();
    }
}
// Give example of Enum using Bike

enum Bike{
    R15,
    R16,
    R17
}

class EnumDemo{
    public static void main(String[] args) {
        Bike b = Bike.R17;
        System.out.println(b);
    }
}

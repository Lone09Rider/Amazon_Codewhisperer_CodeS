// Code For Abstraction  using car models

class AbstractionDemo {    
    static class Car {
        public void start() {
            System.out.println("Car Started");
        }
    
        public void stop() {
            System.out.println("Car Stopped");
        }
    }
    
    static class Audi extends Car {
        public void start() {
            System.out.println("Audi Started");
        }
    
        public void stop() {
            System.out.println("Audi Stopped");
        }
    }
    
    static class BMW extends Car {
        public void start() {
            System.out.println("BMW Started");
        }
    
        public void stop() {
            System.out.println("BMW Stopped");
        }
    }

    public static void main(String[] args) {
        Car c = new Audi();
        c.start();
        c.stop();
    }
}
// Give a example for Polymorphism using person
class PolymorphismDemo {
	static class Person{
		public void display() {
			System.out.println("Person");
		}
	}
	
	static class Student extends Person{
		public void display() {
			System.out.println("Student");
		}
	}
	
	static class Teacher extends Person{
		public void display() {
			System.out.println("Teacher");
		}
	}
    public static void main(String[] args) {
		Person p = new Student();
		p.display();
	}
}

import java.util.Scanner;
/* Write a FCFS algorithm for Pet Treatment based on available Veterinarians including critical cases. Use Pet Names and Doctor Names*/

public class FCFS_Pet {
    public static void main(String[] args) {
        
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter the number of patients: ");
            int n = sc.nextInt();
            String[] patients = new String[n];
            String[] doctors = new String[n];
            System.out.println("Enter the names of the patients: ");
            for (int i = 0; i < n; i++) {
                patients[i] = sc.next();
            }
            System.out.println("Enter the names of the doctors: ");
            for (int i = 0; i < n; i++) {
                doctors[i] = sc.next();
            }
            System.out.println("The order of the patients is: ");
            for (int i = 0; i < n; i++) {
                System.out.println(patients[i] + " allocated to " + doctors[i]);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
/* Based on the regex pattern output implement If..else condition */

import java.util.regex.*;
class IfElse{
	public static void main(String[] args) {
		String str = "Hello World";
		Pattern p = Pattern.compile("Heoll");
		Matcher m = p.matcher(str);
		if(m.find()){
			System.out.println("Match Found");
		}
		else{
			System.out.println("Match Not Found");
		}
	}
}
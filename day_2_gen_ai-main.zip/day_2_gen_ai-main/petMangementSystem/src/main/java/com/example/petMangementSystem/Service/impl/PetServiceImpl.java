package com.example.petMangementSystem.Service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.petMangementSystem.Entity.Pet;
import com.example.petMangementSystem.Repository.PetRepository;
import com.example.petMangementSystem.Service.PetService;

// Create PetServiceImpl implements PetService

@Service
public class PetServiceImpl implements PetService {

	// Dependency Injection using @Autowired
	@Autowired
	private PetRepository petRepository;
	
	
	@Override
	// Get all pets from petRepository
	public List<Pet> getAllPets() {
		return petRepository.findAll();
	}

	@Override
	// Save pet to petRepository
	public Pet savePet(Pet pet) {
		return petRepository.save(pet);
	}

	@Override
	// Delete pet from petRepository
	public String deletePet(Long id) {
		petRepository.deleteById(id);
		return "Pet Deleted Successfully";
	}
	
}

package com.example.petMangementSystem.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.petMangementSystem.Entity.Pet;
import com.example.petMangementSystem.Service.PetService;

@Controller
public class PetController {
	
	private PetService petService;

	public PetController(PetService petService) {
		super();
		this.petService = petService;
	}
	
	@GetMapping("/pets")
	public String listPets(Model model) {
		model.addAttribute("pets", petService.getAllPets());
		return "pets";
	}
	
	@GetMapping("/pets/new")
	public String createPetForm(Model model) {
		Pet pet = new Pet();
		model.addAttribute("pet", pet);
		return "create_pet";
	}
	
	@PostMapping("/pets")
	public String savePet(@ModelAttribute("pet") Pet pet) {
		petService.savePet(pet);
		return "redirect:/pets";
	}

	@GetMapping("/pets/del")
	public String delPet(@RequestParam Long id) {
		petService.deletePet(id);
		return "redirect:/pets";
	}
}

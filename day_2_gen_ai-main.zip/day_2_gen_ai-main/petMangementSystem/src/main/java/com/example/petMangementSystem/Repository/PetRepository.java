package com.example.petMangementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.petMangementSystem.Entity.Pet;

//  Create a PetRepository interface that extends JpaRepository

public interface PetRepository extends JpaRepository<Pet, Long> {

}

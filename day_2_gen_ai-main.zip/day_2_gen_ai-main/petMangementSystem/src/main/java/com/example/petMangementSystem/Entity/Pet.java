package com.example.petMangementSystem.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// Create a Class Pet with Long id, breed String, name String, owner String, seviority int

@Entity
@Table(name = "pets")
public class Pet {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String breed;
	private String name;
	private String owner;

	// Create a Constructor with all fields except id

	public Pet(String breed, String name, String owner) {
		super();
		this.breed = breed;
		this.name = name;
		this.owner = owner;
	}

	// Generate Getters and Setters

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	

	public Pet() {
		super();
	}
	// Create ToString Method
	@Override
	public String toString() {
		return "Pet [id=" + id + ", breed=" + breed + ", name=" + name + ", owner=" + owner + "]";
	}
}

package com.example.petMangementSystem.Service;

import java.util.List;

import com.example.petMangementSystem.Entity.Pet;

// Create a PetService layer interface

public interface PetService {
	List<Pet> getAllPets();
	
	Pet savePet(Pet pet); 

	String deletePet(Long id);
}

/* Implement Regex Pattrn using Switch Case */ 

import java.util.Scanner;
import java.util.regex.Pattern;

public class SwitchCase_Regex {
    public static void main(String[] args) {
        
        // Implement Regex Pattern
        String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";

        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter Email ID: ");
            String email = sc.nextLine();
            
            Pattern pattern = Pattern.compile(regex);
            boolean result = pattern.matcher(email).matches();
            
            // Implement switch case to check if the email matches the input

            if (result == true) {
                switch (email) {
                    case "sr009j@gmail.com":
                        System.out.println("Welcome Sir!!");
                        break;
                }
            } 
            else {
                System.out.println("Invalid Email ID");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    
    }
}
package OOPs.Inheritance.Multiple;

public class BMW extends Car implements Vehicle{

	public String Run() {
		return "I am Running";
	}
	public String my_name() {
		return "I am BMW";
	}

}

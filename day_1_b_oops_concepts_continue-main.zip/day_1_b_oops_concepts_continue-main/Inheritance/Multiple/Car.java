package OOPs.Inheritance.Multiple;

public class Car {
	
	public String name()
	{
		return "I am Car";
	}
}

package OOPs.Inheritance.Multiple;

public interface Vehicle {
	String Run();
}

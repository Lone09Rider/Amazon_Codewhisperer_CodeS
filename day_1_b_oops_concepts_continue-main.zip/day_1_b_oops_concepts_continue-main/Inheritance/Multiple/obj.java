package OOPs.Inheritance.Multiple;

public class obj {
	public static void main(String[] args) {
		
		BMW b = new BMW();
		System.out.println(b.my_name());
		System.out.println(b.name());
		System.out.println(b.Run());
		
	}
}

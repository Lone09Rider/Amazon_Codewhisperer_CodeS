package OOPs.Inheritance.MultiLevel;

public class Vehicle {
	public String Run()
	{
		return "Running";
	}
}

package OOPs.Inheritance.MultiLevel;

public class Car extends Vehicle{
	public String name() {
		return "I am Car";
	}
}

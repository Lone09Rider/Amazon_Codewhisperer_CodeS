package OOPs.Inheritance.MultiLevel;

public class BMW extends Car{
	
	public String c_name() {
		return "I am BMW and a CAR";
	}

}

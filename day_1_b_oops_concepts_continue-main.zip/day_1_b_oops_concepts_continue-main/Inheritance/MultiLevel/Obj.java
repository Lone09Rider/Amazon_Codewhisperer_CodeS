package OOPs.Inheritance.MultiLevel;

public class Obj {
	
	public static void main(String[] args) {
		BMW car = new BMW();
		System.out.println(car.Run());
		System.out.println(car.name());
		System.out.println(car.c_name());
	}

}

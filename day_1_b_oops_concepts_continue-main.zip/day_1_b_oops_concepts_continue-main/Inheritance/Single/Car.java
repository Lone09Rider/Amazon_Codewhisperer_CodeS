package OOPs.Inheritance.Single;

public class Car extends Vehicle{
	public String name() {
		return "I am Car";
	}
}

package OOPs.Inheritance.Single;

public class Vehicle {
	public String Run()
	{
		return "Running";
	}
}

package OOPs.Inheritance.Single;

public class Obj {
	
	public static void main(String[] args) {
		Car car = new Car();
		System.out.println(car.Run());
		System.out.println(car.name());
	}

}

package com.user.contactservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.user.contactservice.entity.Pets;

// JPA Repo for doing SQL CRUD Operations
public interface PetRepo extends JpaRepository<Pets, Integer>{
	
	// To select Everything from DB
	@Query("SELECT p FROM Pets p")
	List<Pets> findAllinSQL();
	
	// To select type and owner From Pet in DB
	@Query(value = "SELECT type, owner FROM Pets", nativeQuery = true)
	List<Object[]> findPetOwnerMapping();
	
	// To give one pet with id = user given id
	@Query("SELECT p FROM Pets p WHERE p.id = :id")
	Pets findPetById(@Param("id") int id);

}

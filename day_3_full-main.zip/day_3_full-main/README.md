# CSS Is Used in All the Angular Projects

# Routing Module is Also used in All the Angular Projects

# Have added one Image for validation also

package com.example.petMangementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetMangementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

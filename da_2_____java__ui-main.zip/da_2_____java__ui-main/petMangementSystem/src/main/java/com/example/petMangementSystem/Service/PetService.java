package com.example.petMangementSystem.Service;

import java.util.List;

import com.example.petMangementSystem.Entity.Pet;

public interface PetService {
	List<Pet> getAllPets();
	
	Pet savePet(Pet pet); 
}

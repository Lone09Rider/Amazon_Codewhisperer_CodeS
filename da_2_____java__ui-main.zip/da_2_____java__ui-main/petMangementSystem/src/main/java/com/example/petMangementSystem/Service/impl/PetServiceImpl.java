package com.example.petMangementSystem.Service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.petMangementSystem.Entity.Pet;
import com.example.petMangementSystem.Repository.PetRepository;
import com.example.petMangementSystem.Service.PetService;

@Service
public class PetServiceImpl implements PetService {

	private PetRepository petRepository;
	
	
	
	public PetServiceImpl(PetRepository petRepository) {
		super();
		this.petRepository = petRepository;
	}

	@Override
	public List<Pet> getAllPets() {
		return petRepository.findAll();
	}

	@Override
	public Pet savePet(Pet pet) {
		return petRepository.save(pet);
	}

}

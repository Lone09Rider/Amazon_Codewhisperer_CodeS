package com.example.petMangementSystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.petMangementSystem.Entity.Pet;
import com.example.petMangementSystem.Repository.PetRepository;

@SpringBootApplication
public class PetMangementSystemApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(PetMangementSystemApplication.class, args);
	}

	@Autowired
	private PetRepository petRepository;
	
	@Override
	public void run(String... args) throws Exception {
//		Pet pet1 = new Pet("Mountain Dog", "Husky", "Agent Rj", 2);
//		petRepository.save(pet1);
//		
//		Pet pet2 = new Pet("Mountain Cat", "Kitty", "Agent K", 1);
//		petRepository.save(pet2);
	}

}

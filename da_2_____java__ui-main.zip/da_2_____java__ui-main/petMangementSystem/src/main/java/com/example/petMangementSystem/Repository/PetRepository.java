package com.example.petMangementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.petMangementSystem.Entity.Pet;

public interface PetRepository extends JpaRepository<Pet, Long> {

}

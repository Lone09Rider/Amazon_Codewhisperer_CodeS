package com.example.DoctorAssignments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorAssignmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}

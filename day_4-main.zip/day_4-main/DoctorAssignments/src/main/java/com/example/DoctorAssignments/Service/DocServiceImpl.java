package com.example.DoctorAssignments.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DoctorAssignments.POJO.PetDoctors;
import com.example.DoctorAssignments.Repo.DocRepo;

@Service
public class DocServiceImpl implements DocService {
	
	@Autowired
	private DocRepo repo;

	@Override
	public List<PetDoctors> getAllDocs() {
		return repo.findAll();
	}

	@Override
	public PetDoctors getOneDocs(int id) {
		return repo.findById(id).get();
	}

	@Override
	public PetDoctors addDocs(PetDoctors doctor) {
		return repo.save(doctor);
	}

//	@Override
//	public List<PetDoctors> getAvailableDocs(PetDoctors doctors) {
//		
//		if (doctors.getIsAvailable() == true) {
//			return repo.findAll();
//		}
//	}
	
}

package com.example.DoctorAssignments.Service;

import java.util.List;

import com.example.DoctorAssignments.POJO.PetDoctors;

public interface DocService {
	public List<PetDoctors> getAllDocs();
	public PetDoctors getOneDocs(int id);
	public PetDoctors addDocs(PetDoctors doctor);
//	public List<PetDoctors> getAvailableDocs(PetDoctors doctors);
}

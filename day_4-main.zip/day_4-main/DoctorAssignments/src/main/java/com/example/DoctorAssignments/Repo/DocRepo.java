package com.example.DoctorAssignments.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.DoctorAssignments.POJO.PetDoctors;

@Repository
public interface DocRepo extends JpaRepository<PetDoctors, Integer>{
//	@Query(value = "SELECT p FROM pet_doctors p ORDER BY docname")  
//	public Optional<List<PetDoctors>> yoDoc();
}

package com.example.DoctorAssignments.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.DoctorAssignments.FeignClientDemo;
import com.example.DoctorAssignments.POJO.PetDoctors;
import com.example.DoctorAssignments.POJO.PetTreatment;
import com.example.DoctorAssignments.Service.DocService;

@RestController
public class DocController {
	
//	@Autowired
//	private DocRepo repo; 

	@Autowired
	private DocService service;
	
	@Autowired
	FeignClientDemo clientDemo;

	
//	@GetMapping("/sort")
//	public List<PetDoctors> findDocsSorted() {
//		return repo.yoDoc().get();
//	}
//	
	@GetMapping
	public List<PetDoctors> getAll() {
		return service.getAllDocs();
	}

	@GetMapping("/{id}")
	public PetDoctors getOne(@PathVariable("id") int id) {
//		clientDemo.getOnePet(id);
		return service.getOneDocs(id);
	}
	
	@GetMapping("/pet/{id}")
	public PetTreatment getOnePet(@PathVariable("id") int id) {
		return clientDemo.getOnePet(id);
	}

	@PostMapping
	public PetDoctors addOne(@RequestBody PetDoctors doctors) {
		return service.addDocs(doctors);
	}

	@Override
	public String toString(){
		return "DocController [service=" + service + "]";
	}

}

package com.example.PeTClininC.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.PeTClininC.POJO.PetTreatment;
import com.example.PeTClininC.Repo.PetTreatmenTRepository;

@Service
public class PetServiceImpl implements PetService {

	@Autowired
	PetTreatmenTRepository repository;

	@Override
	public String createPetInfo(PetTreatment pet) throws Exception {
		if (pet.getPetBreed().equals("Dog") || pet.getPetBreed().equals("Cat")) {
			repository.save(pet);
			return "Data Added Successfully";
		} else {
			throw new Exception("Sorry, we treat Dogs and Cats only!");
		}

	}

	@Override
	public String updatePetInfo(PetTreatment pet) throws Exception {
		if (pet.getPetBreed().equals("Dog") || pet.getPetBreed().equals("Cat")) {
			repository.save(pet);
			return "Data Updated Successfully";
		}
		else {
			throw new Exception("Sorry, we treat Dogs and Cats only!");
		}
	}

	@Override
	public String deletePetInfo(int id) {
		repository.deleteById(id);
		return "Data Deleted Successfully";
	}

	@Override
	public PetTreatment getOne(int id) {
		PetTreatment petTreatment = repository.findById(id).get();
		return petTreatment;
	}

	@Override
	public List<PetTreatment> getAllTreats() {
		return repository.findAll();
	}

}

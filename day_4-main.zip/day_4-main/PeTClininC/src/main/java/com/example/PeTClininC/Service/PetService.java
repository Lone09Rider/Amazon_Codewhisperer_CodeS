package com.example.PeTClininC.Service;

import java.util.List;

import com.example.PeTClininC.POJO.PetTreatment;

public interface PetService {
	public String createPetInfo(PetTreatment pet) throws Exception;
	public String updatePetInfo(PetTreatment pet) throws Exception;
	public String deletePetInfo(int id);
	public PetTreatment getOne(int id);
	public List<PetTreatment> getAllTreats();
}

package com.example.PeTClininC.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.PeTClininC.POJO.PetTreatment;
import com.example.PeTClininC.Service.PetService;

@RestController
@RequestMapping("/clinic")
public class PetTreatmentController {
	
//	@Autowired
//	private RestTemplate template;
	
	@Autowired
	private PetService impl;
	
	@GetMapping("/{id}")
	public PetTreatment getOnePet(@PathVariable("id") int id) {
//		PetTreatment pet = impl.getOne(id);
//		List doctors = template.getForObject("https://localhost:8081/"+pet.getPetId(), List.class);
//		pet.setPetDoc(doctors);
		return impl.getOne(id);
	}
	
	@GetMapping
	public List<PetTreatment> getAllPets() {
		return impl.getAllTreats();
	}
	
	@PostMapping
	public String creteTreat(@RequestBody PetTreatment pet) {
		try {
			impl.createPetInfo(pet);
		} catch (Exception e) {
			return e.getMessage();
		}
		return "Treatment info Successfully entered";
	}
	
	@PutMapping
	public String updateTreat(@RequestBody PetTreatment pet) {
		try {
			impl.updatePetInfo(pet);
		} catch (Exception e) {
			return e.getMessage();
		}
		return "Updated Successfully";
	}
	
	@DeleteMapping("/{id}")
	public String deleteOne(@PathVariable("id") int id) {
		impl.deletePetInfo(id);
		return "Deleted Successfully";
	}
	
}

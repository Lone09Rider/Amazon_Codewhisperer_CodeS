package com.example.PeTClininC.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.PeTClininC.POJO.PetTreatment;

@Repository
public interface PetTreatmenTRepository extends JpaRepository<PetTreatment, Integer> {
	
}

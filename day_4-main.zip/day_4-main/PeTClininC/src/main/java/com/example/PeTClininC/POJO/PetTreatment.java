package com.example.PeTClininC.POJO;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "PeT_TreatmenT")
public class PetTreatment {
	
	@Id
	private int petId;
	private String petName;
	private String petBreed;
	private String treatmentDescription;
	private String ownerName;
	
//	@ManyToOne(targetEntity= PetDoctors.class,cascade = CascadeType.ALL)
//    @JoinColumn(name="id")
//	private List<PetDoctors> petDoc;

//	public List<PetDoctors> getPetDoc() {
//		return petDoc;
//	}
//
//	public void setPetDoc(List<PetDoctors> petDoc) {
//		this.petDoc = petDoc;
//	}
	
	

	public PetTreatment(int petId, String petName, String petBreed, String treatmentDescription, String ownerName) {
		super();
		this.petId = petId;
		this.petName = petName;
		this.petBreed = petBreed;
		this.treatmentDescription = treatmentDescription;
		this.ownerName = ownerName;
//		this.petDoc = petDoc;
	}

	public PetTreatment() {
		super();
	}

	public int getPetId() {
		return petId;
	}

	public void setPetId(int petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetBreed() {
		return petBreed;
	}

	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}

	public String getTreatmentDescription() {
		return treatmentDescription;
	}

	public void setTreatmentDescription(String treatmentDescription) {
		this.treatmentDescription = treatmentDescription;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	@Override
	public String toString() {
		return "PetTreatment [petId=" + petId + ", petName=" + petName + ", petBreed=" + petBreed
				+ ", treatmentDescription=" + treatmentDescription + ", ownerName=" + ownerName + ", petDoc="
				+ "]";
	}

}

//package com.example.PeTClininC;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//
//@Entity
//public class PetDoctors {
//	@Id
////	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int id;
//	private String docname;
//	private String docspeciality;
//	private Boolean isavailable = true;
//
//	public PetDoctors(String docname, String docspeciality, Boolean isavailable) {
//		super();
//		this.docname = docname;
//		this.docspeciality = docspeciality;
//		this.isavailable = isavailable;
//	}
//
//	public PetDoctors() {
//		super();
//	}
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getDocname() {
//		return docname;
//	}
//
//	public void setDocname(String docname) {
//		this.docname = docname;
//	}
//
//	public String getDocspeciality() {
//		return docspeciality;
//	}
//
//	public void setDocspeciality(String docspeciality) {
//		this.docspeciality = docspeciality;
//	}
//
//	public Boolean getIsavailable() {
//		return isavailable;
//	}
//
//	public void setIsavailable(Boolean isavailable) {
//		this.isavailable = isavailable;
//	}
//
//}



package com.example.PeTClininC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeTClininCApplicationTests {

	@Test
	void contextLoads() {
	}

}

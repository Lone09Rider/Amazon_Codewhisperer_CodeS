package com.user.contactservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// This Class will add a table to DB with name as pets
@Entity
public class Pets {
	// To Give Primary Key
	@Id
	// To auto generate the primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String type;
	private String name;
	private String owner;

	// Base Cunstructor
	public Pets() {
		super();
	}

	// Constructor with args
	public Pets(String type, String name, String owner) {
		super();
		this.type = type;
		this.name = name;
		this.owner = owner;
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	// To String Method
	@Override
	public String toString() {
		return "Pets [id=" + id + ", type=" + type + ", name=" + name + ", owner=" + owner + "]";
	}

}

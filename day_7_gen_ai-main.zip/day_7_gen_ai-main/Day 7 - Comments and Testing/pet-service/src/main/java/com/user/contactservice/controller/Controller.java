package com.user.contactservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.contactservice.Repository.PetRepo;
import com.user.contactservice.entity.Pets;

@RestController
public class Controller {
	// To get All methods from PetRepo Interface
	@Autowired
	private PetRepo repo;
	
	// All process at localhost:8080
	// if you add /pets to ablove url you will get all pet details from DB
	@GetMapping("/pets")
	public List<Pets> allPets() {
		return repo.findAllinSQL();
	}
	
	// if you add /pets to ablove url you will get all pet details of one pet whith id as given in the uri from DB
	@RequestMapping("/pets/{id}")
	public Pets getPetById(@PathVariable("id") int id) {
		return repo.findPetById(id);
	}
	
	// Only returns pet names and owner names
	@RequestMapping("/pet-owner")
	List<Object[]> findPetOwnerMapping() {
		return repo.findPetOwnerMapping();
	}
}

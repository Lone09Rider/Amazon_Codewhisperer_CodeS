package com.user.contactservice;

import java.util.ArrayList;
import java.util.List;

// import java.util.ArrayList;
// import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.user.contactservice.Repository.PetRepo;
import com.user.contactservice.entity.Pets;

@SpringBootApplication
public class PetServiceApplication implements CommandLineRunner {
	
	@Autowired
	PetRepo repo;
	

	public static void main(String[] args) {
		SpringApplication.run(PetServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		repo.save(new Pets("Dog", "Whusky", "SRj"));
		repo.save(new Pets("Cat", "Mew", "KK"));
		repo.save(new Pets("Dog", "Woofy", "Nish-JD"));
		List<Pets> pets = new ArrayList<>();
		pets = repo.findAll();
		System.out.println(pets);
	}

}

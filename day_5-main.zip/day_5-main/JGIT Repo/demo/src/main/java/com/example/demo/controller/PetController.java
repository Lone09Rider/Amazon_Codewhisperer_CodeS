package com.example.demo.controller;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.GitService;

@RestController
public class PetController {
	
	 
	
	@Autowired
	private GitService gitService;
	
	
	
	 
	@GetMapping("/clone")
	public String cloneRepository(@RequestParam(defaultValue = "C:\\Users\\user\\Desktop\\Daywise Upload\\Day 5\\JGIT Repo\\repo") String localpath, @RequestParam(defaultValue = "Shruti.Ranjan@cognizant.com") String username, @RequestParam(defaultValue = "Rjblaze@01") String password, @RequestParam(defaultValue = "https://gitlab.stackroute.in/Shruti.Ranjan/day_5.git") String remoteURL ) {
	System.out.println(localpath);
	System.out.println(username);
	System.out.println(password);
	System.out.println(remoteURL);
 		try{
			gitService.cloneRepository(localpath, remoteURL, username, password);
			return "Repository Clone Successfully";
		}catch (GitAPIException e) {
			e.printStackTrace();
			return "Error in Cloning Repository" + e.getMessage();
		}
	
		
	}
	

}

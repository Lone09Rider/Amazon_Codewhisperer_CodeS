package com.example.demo.service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.GitCloneRequest;

public class GitCloneClient {
	
	public  void main(String[] args) {
        String cloneUrl = "http://localhost:8080/clone"; 
        RestTemplate restTemplate = new RestTemplate();


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);


      
        GitCloneRequest request = new GitCloneRequest();
        request.setLocalpath("C:\\repo");
        request.setRemoteURL("https://gitlab.stackroute.in/Shruti.Ranjan/day_5.git");
        request.setUsername("Shruti.Ranjan@cognizant.com");
        request.setPassword("Rjblaze@01");


        HttpEntity<GitCloneRequest> entity = new HttpEntity<>(request, headers);

        ResponseEntity<String> response = restTemplate.exchange(cloneUrl, HttpMethod.POST, entity, String.class);

 
        if (response.getStatusCode() == HttpStatus.OK) {
            System.out.println("Cloning result: " + response.getBody());
        } else {
            System.err.println("Failed to clone repository.");
        }
    }
	
	

}

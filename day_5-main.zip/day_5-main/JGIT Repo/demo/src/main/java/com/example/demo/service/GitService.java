package com.example.demo.service;

import java.io.File;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullCommand;
import org.eclipse.jgit.api.PushCommand;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.springframework.stereotype.Service;

@Service
public class GitService {
	
	public void cloneRepository(String localpath, String remoteURL, String username, String password ) throws GitAPIException{
		Git.cloneRepository(
				).setURI(remoteURL)
		         .setDirectory(new File(localpath))
		         .setCredentialsProvider(new UsernamePasswordCredentialsProvider(username, password))
		         .call();
		
	}
	
	public void pushChanges(String localpath, String username, String password) throws GitAPIException{
		
		try(Git git = Git.open(new File(localpath))){
			PushCommand pushCommand = git.push().setCredentialsProvider(new UsernamePasswordCredentialsProvider(username, password));
			pushCommand.call();				                     
		}catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void pullChanges(String localpath) throws GitAPIException{
		
		try(Git git = Git.open(new File(localpath))){
			PullCommand pullCommand = git.pull();
			pullCommand.call();	
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}

}

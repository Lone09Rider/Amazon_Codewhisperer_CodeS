package com.user.contactservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.user.contactservice.entity.Pets;

public interface PetRepo extends JpaRepository<Pets, Integer>{
	
	@Query("SELECT p FROM Pets p")
	List<Pets> findAllinSQL();
	
	@Query(value = "SELECT type, owner FROM Pets", nativeQuery = true)
	List<Object[]> findPetOwnerMapping();
	
	@Query("SELECT p FROM Pets p WHERE p.id = :id")
	Pets findPetById(@Param("id") int id);

}

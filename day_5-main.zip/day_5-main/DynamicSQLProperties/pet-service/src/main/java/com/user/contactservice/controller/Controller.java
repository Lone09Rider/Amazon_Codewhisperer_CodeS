package com.user.contactservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.contactservice.Repository.PetRepo;
import com.user.contactservice.entity.Pets;

@RestController
public class Controller {
	@Autowired
	private PetRepo repo;
	
	@GetMapping("/pets")
	public List<Pets> allPets() {
		return repo.findAllinSQL();
	}
	
	@RequestMapping("/pets/{id}")
	public Pets getPetById(@PathVariable("id") int id) {
		return repo.findPetById(id);
	}
	
	@RequestMapping("/pet-owner")
	List<Object[]> findPetOwnerMapping() {
		return repo.findPetOwnerMapping();
	}
}

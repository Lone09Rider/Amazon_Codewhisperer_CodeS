package com.example;

import java.util.*;
import java.util.stream.Collectors;

public class LoopToStream {
	
	public static void main(String[] args) {
      
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

       
        System.out.println("For loop:");
        for (Integer number : numbers) {
            System.out.println(number);
        }

      
        System.out.println("Streams:");
        numbers.forEach(System.out::println);

        

       
        List<String> alphas = Arrays.asList("A", "B", "C");
        List<String> capitalizedalphas = new ArrayList<>();

       
        for (String alpha : alphas) {
            capitalizedalphas.add(alpha.toUpperCase());
        }

        System.out.println("For Loop: " + capitalizedalphas);

 
        List<String> capitalizedalphasStream = alphas.stream()
            .map(String::toUpperCase)
            .collect(Collectors.toList());

        System.out.println("Streams: " + capitalizedalphasStream);
    }

}

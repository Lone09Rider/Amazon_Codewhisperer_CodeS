/**
 * 
 */
/**
 * @author 2173390
 *
 */
module JavaLoop {
}
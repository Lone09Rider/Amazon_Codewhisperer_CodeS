a) Design Patterns

b) Programming Language Constructs

c) Algorithm’s  for problem solving

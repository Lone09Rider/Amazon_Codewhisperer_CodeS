public class Pet {
    private String name;
    private String breed;
    private String sound;

    private Pet() {
    }

    public String getName() {
        return name;
    }

    public String getBreed() {
        return breed;
    }

    public String getSound() {
        return sound;
    }

    public static class Builder {
        private String name;
        private String breed;
        private String sound;

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder breed(String breed) {
            this.breed = breed;
            return this;
        }

        public Builder sound(String sound) {
            this.sound = sound;
            return this;
        }

        public Pet build() {
            Pet pet = new Pet();
            pet.name = this.name;
            pet.breed = this.breed;
            pet.sound = this.sound;

            return pet;
        }
    }
}
public class MainCLass {
    public static void main(String[] args) {
        Pet pet = new Pet.Builder().name("Husky").breed("Siberian Dog Breed").sound("Wrrrrroooooff!!").build();

        System.out.println("I am '" + pet.getName() + "' and I am a '" + pet.getBreed() + "'When I am friendly I '" + pet.getSound()+ "''.");
    }
}

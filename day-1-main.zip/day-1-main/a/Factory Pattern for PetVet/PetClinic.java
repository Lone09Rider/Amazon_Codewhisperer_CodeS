public class PetClinic {
    public Pet createPet(String type, String name, int age) {
        if(type.equals("squirel")){
            return new Squirel(name, age);
        } else if(type.equals("dog")){
            return new Dog(name, age);
        }
        
        throw new IllegalArgumentException("New Breed : " + type);
    } 
}

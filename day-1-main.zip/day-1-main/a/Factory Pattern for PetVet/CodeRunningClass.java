public class CodeRunningClass {
    public static void main(String[] args) {
        PetClinic pf = new PetClinic();

        Pet mySquirel = pf.createPet("squirel", "Tiku", 2);

        mySquirel.makeSound();

        Pet myDog = pf.createPet("dog", "Sheru", 3);

        myDog.makeSound();

        Pet cat = pf.createPet("cat", "unknown", 0);

        cat.makeSound();
    }
}

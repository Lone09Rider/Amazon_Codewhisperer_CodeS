public class Squirel extends Pet {

    public Squirel(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println("Squeak!! Squeek!! I am Cute :-)");
    }
    
}

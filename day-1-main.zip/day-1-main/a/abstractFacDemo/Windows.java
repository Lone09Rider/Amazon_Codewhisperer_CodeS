package abstractFacDemo;

public class Windows implements OS {
    public void specs() {
        System.out.println("Battery Low. WIll Drain in 1 min");
    }
}

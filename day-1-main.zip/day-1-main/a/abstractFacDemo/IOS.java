package abstractFacDemo;

public class IOS implements OS {

    @Override
    public void specs() {
        System.out.println("Most Sercured OS");
    }
    
}

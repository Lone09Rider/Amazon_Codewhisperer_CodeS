package abstractFacDemo;

public class Android implements OS{
    public void specs() {
        System.out.println("Most Powerful OS");
    }
}

package abstractFacDemo;

public interface OS {
    public void specs();
}

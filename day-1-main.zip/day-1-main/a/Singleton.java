class A {
    static A obj = new A();

    private A() {

    }

    public static A getInstance() {
        return obj;
    }
}

class Singleton {
    public static void main(String[] args) {
        A obj1 = A.getInstance();
        A obj2 = A.getInstance();

        System.out.println(obj1 +", "+obj2);
    }
}
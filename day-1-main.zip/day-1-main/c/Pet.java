public class Pet {
    private String name;
    private String type;
    private int criticality;

    
    public Pet(String name, String type, int criticality) {
        this.name = name;
        this.type = type;
        this.criticality = criticality;
    }


    public String getName() {
        return name;
    }


    public String getType() {
        return type;
    }


    public int getCriticality() {
        return criticality;
    }
}
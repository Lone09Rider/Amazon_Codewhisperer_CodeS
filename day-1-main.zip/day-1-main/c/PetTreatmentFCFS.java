import java.util.ArrayList;
import java.util.List;

public class PetTreatmentFCFS {
    public static void main(String[] args) {
        List<Veterinarian> availableVets = new ArrayList<>();
        availableVets.add(new Veterinarian("Dr. A", true));
        availableVets.add(new Veterinarian("Dr. B", true));
        availableVets.add(new Veterinarian("Dr. C", true));

        List<Pet> pets = new ArrayList<>();
        pets.add(new Pet("Jack", "Dog", 2));
        pets.add(new Pet("Whiskers", "Squirel", 1));
        pets.add(new Pet("Misty", "Dog", 3));

        List<Veterinarian> assignedVets = new ArrayList<>();
        for (Pet pet : pets) {
            Veterinarian assignedVet = null;
            for (Veterinarian vet : assignedVets) {
                if (vet.isAvailable()) {
                    assignedVet = vet;

                    assignedVets.add(assignedVet);

                    vet.setAvailable(false);
                    break;
                }
            }

            if (assignedVet == null) {
                while(assignedVet == null){
                    for (Veterinarian vet : availableVets) {
                        if(vet.isAvailable()){
                            assignedVet = vet;
                            assignedVets.add(assignedVet);
                            vet.setAvailable(false);
                            break;
                        }
                    }
                }
            }
            System.out.println(pet.getName()+" is assigned to "+assignedVet.getName()+" for treatment");
        }

        System.out.println("\nAssigned Vets are : \n");
        for (int i = 0; i < pets.size(); i++) {
            System.out.println(pets.get(i).getName()+" : "+assignedVets.get(i).getName());
        }

        System.out.println("First Come First Served Successfully!!!");
    }
}

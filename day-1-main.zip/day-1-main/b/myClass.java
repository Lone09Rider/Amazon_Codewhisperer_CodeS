public class myClass {
    public static void main(String[] args) {
        int i = 1;

        while (i <= 10) {
            System.out.println("5 x "+i+" = "+5*i);
            i += 1;
        }

        System.out.println("-----------------");

        int[] x = {1, 2, 3, 4};
        for (int k : x) {
            System.out.println(k);
        }

        System.out.println("---------------");

        int[][] y = {{1, 2, 3}, {4, 5, 6}};
        for (int[] js : y) {
            for (int k : js) {
                System.out.println(k);
            }
        }
    }
}

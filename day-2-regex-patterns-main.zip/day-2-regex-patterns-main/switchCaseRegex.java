package regexDay;

public class switchCaseRegex {
    public static void main(String[] args) {
        String input = "Hello World Java";
        switch (input) {
            case "Hello":
                System.out.println("Pattern 1 Matched");
                break;
            case "World":
                System.out.println("Pattern 2 Matched");
                break;
            case "Java":
                System.out.println("Pattern 3 Matched");
                break;
            default:
                System.out.println("None Matched");
                break;
        }
    }
}

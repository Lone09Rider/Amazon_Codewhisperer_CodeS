package regexDay;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class petOwnerEmail {
    public static void main(String[] args) {
        String email = "kiraBeast@gmail.com";

        String pattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

        Pattern emailPattern = Pattern.compile(pattern);
        Matcher matcher = emailPattern.matcher(email);

        if (matcher.matches()) {
            System.out.println("You are allowed, Mail is Valid");
        } else {
            System.out.println("You are not allowed, Invalid ID");
        }
    }
}

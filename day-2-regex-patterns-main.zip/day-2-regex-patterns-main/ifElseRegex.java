package regexDay;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ifElseRegex {
    public static void main(String[] args) {
        String input = "2023";
        String pattern = ".*2023.*";

        Pattern regexPattern = Pattern.compile(pattern);
        Matcher matcher = regexPattern.matcher(input);

        if (matcher.find()) {
            System.out.println("Found in Input");
        } else {
            System.out.println("Pattern Not Found");
        }
    }
}

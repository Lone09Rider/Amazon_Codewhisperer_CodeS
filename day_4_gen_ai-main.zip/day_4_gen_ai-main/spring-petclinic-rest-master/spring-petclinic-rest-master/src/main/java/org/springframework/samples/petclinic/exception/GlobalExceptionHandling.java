package org.springframework.samples.petclinic.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

public class GlobalExceptionHandling extends ResponseEntityExceptionHandler{

    //Exception handler for pet not found with response entity
    @ExceptionHandler(PetNotFound.class)
    public ResponseEntity<Object> handlePetNotFoundException(PetNotFound ex) {
        PetException petException = new PetException(ex.getMessage(), ex.getCause(), HttpStatus.NOT_FOUND);
        return new ResponseEntity<>("Pet not found", HttpStatus.NOT_FOUND);
    }

    //exception handler for EmptyInputException
    @ExceptionHandler(EmptyInputException.class)
    public ResponseEntity<Object> handleEmptyInputException(EmptyInputException ep) {
        PetException petException = new PetException(ep.getMessage(), ep.getCause(), HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>("Empty input", HttpStatus.BAD_REQUEST);
    }

}

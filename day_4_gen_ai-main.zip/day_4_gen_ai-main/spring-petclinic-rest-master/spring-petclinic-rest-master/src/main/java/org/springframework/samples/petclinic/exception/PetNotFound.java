package org.springframework.samples.petclinic.exception;

public class PetNotFound extends RuntimeException{
    public PetNotFound(String message) {
        super(message);
    }

    public PetNotFound(String message, Throwable cause) {
        super(message, cause);
    }



}

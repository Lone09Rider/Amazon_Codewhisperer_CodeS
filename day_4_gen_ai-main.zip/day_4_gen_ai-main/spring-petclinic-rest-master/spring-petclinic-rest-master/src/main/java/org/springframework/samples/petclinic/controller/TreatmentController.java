package org.springframework.samples.petclinic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.samples.petclinic.exception.EmptyInputException;
import org.springframework.samples.petclinic.exception.PetNotFound;
import org.springframework.samples.petclinic.entity.PetTreatment;
import org.springframework.samples.petclinic.service.PetTreatmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/petClinic")
public class TreatmentController {

    //Autowire the PetTreatmentService
    @Autowired
    private PetTreatmentService service;

    //to post the petTreatment details
    @PostMapping("/savePet")
    public ResponseEntity<PetTreatment> addPetTreatment(@RequestBody PetTreatment pet) throws EmptyInputException {
        PetTreatment savedPet = service.addPetTreatment(pet);
        return new ResponseEntity<PetTreatment>(savedPet, HttpStatus.CREATED);
    }

    //to get the list of petTreatment details
    @GetMapping("/getTreatment")
    public ResponseEntity<List<PetTreatment>> getPetTreatment() {
        List<PetTreatment> petTreatment = service.getPetTreatment();
        return new ResponseEntity<List<PetTreatment>>(petTreatment, HttpStatus.OK);

    }

    //to get the petTreatment details by id
    @GetMapping("/get/{id}")
    public ResponseEntity<PetTreatment> getPetTreatmentById(@PathVariable("id") int id) throws PetNotFound {
        PetTreatment petTreatment = service.getPetTreatmentById(id);
        return new ResponseEntity<PetTreatment>(petTreatment, HttpStatus.OK);
    }

    //to update the petTreatment details
    @PutMapping("/updatePet")
    public ResponseEntity<PetTreatment> updatePetTreatment(@RequestBody PetTreatment pet) throws EmptyInputException{
        PetTreatment updatedPet = service.updatePetTreatment(pet);
        return new ResponseEntity<PetTreatment>(updatedPet, HttpStatus.CREATED);
    }

//to delete the petTreatment details by id
    @DeleteMapping("/delete/{id}")
public ResponseEntity<PetTreatment> deletePetTreatment(@PathVariable("id") int id) throws PetNotFound{
        service.deletePetTreatment(id);
        return new ResponseEntity<PetTreatment>(HttpStatus.ACCEPTED);
    }

    // @GetMapping("/vetId")
    // public ResponseEntity<List<PetTreatment>> getPetTreatmentByVetId(@PathVariable int vetId) {
    //     List<PetTreatment> petTreatment = service.getPetTreatmentByVetId(vetId);
    //     if (petTreatment == null) {
    //         return new ResponseEntity<List<PetTreatment>>(HttpStatus.NOT_FOUND);
    //     } else {
    //         return new ResponseEntity<List<PetTreatment>>(petTreatment, HttpStatus.OK);
    //     } 
            
        
    // }
}

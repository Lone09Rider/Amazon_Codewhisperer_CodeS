package org.springframework.samples.petclinic.service;

import org.springframework.samples.petclinic.entity.PetTreatment;

import java.util.List;

public interface PetTreatmentService {

    public PetTreatment addPetTreatment(PetTreatment pet);

    public List<PetTreatment> getPetTreatment();

    public PetTreatment getPetTreatmentById(int id);

    public PetTreatment updatePetTreatment(PetTreatment pet);

    public void deletePetTreatment(int id);

//    public List<PetTreatment> getPetTreatmentByPetTreatments(int vetId);
}

package org.springframework.samples.petclinic.exception;

public class EmptyInputException extends RuntimeException{

    public EmptyInputException(String message, Throwable cause) {
        super(message, cause);
    }
    public EmptyInputException(String message) {
        super(message);
    }

}

package org.springframework.samples.petclinic.repository.springdatajpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.jpa.repository.Query;
import org.springframework.samples.petclinic.entity.PetTreatment;
import org.springframework.stereotype.Repository;

//PetTreatmentRepository interface extends JpaRepository
@Repository
public interface PetTreatmentRepository extends JpaRepository<PetTreatment, Integer>{

    // a custom query to find the list of petType whose vetId is 102
//    @Query("SELECT pt FROM PetTreatment pt WHERE pt.treatment_id = :treatmentId")
//    List<PetTreatment> findByVetId(int vetId);




}

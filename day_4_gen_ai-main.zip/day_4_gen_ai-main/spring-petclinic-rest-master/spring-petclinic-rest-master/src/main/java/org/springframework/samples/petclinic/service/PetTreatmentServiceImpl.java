package org.springframework.samples.petclinic.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.samples.petclinic.exception.EmptyInputException;
import org.springframework.samples.petclinic.exception.PetNotFound;
import org.springframework.samples.petclinic.entity.PetTreatment;
import org.springframework.samples.petclinic.repository.springdatajpa.PetTreatmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

//PetTreatmentServiceImpl implements PetTreatmentService
@Service
public class PetTreatmentServiceImpl implements PetTreatmentService {

    //Autowired the PetTreatmentRepository
    @Autowired
    private PetTreatmentRepository repository;


    @Override
    public PetTreatment addPetTreatment(PetTreatment pet) throws EmptyInputException {
        if(pet.getPetType().isBlank() || pet.getOwnerName().isBlank() )
            throw new EmptyInputException("Pet Type and Owner Name cannot be empty");
        return repository.save(pet);
    }

    @Override
    public List<PetTreatment> getPetTreatment() throws PetNotFound {
//        if(repository.findAll().isEmpty())
//            throw new PetNotFound("No Pet Treatment Found");
        return repository.findAll();
    }

    @Override
    public PetTreatment getPetTreatmentById(int id) throws PetNotFound{
        if(repository.findById(id).isEmpty())
            throw new PetNotFound("No Pet Treatment Found");
        return repository.findById(id).get();
    }

    @Override
    public PetTreatment updatePetTreatment(PetTreatment pet) throws EmptyInputException, PetNotFound
    {
        if(pet.getPetType().isBlank() || pet.getOwnerName().isBlank() )
            throw new EmptyInputException("Pet Type and Owner Name cannot be empty");
        return repository.save(pet);
    }

    @Override
    public void deletePetTreatment(int id) throws PetNotFound
    {
        if(repository.findById(id).isEmpty())
            throw new PetNotFound("No Pet Treatment Found");
        repository.deleteById(id);
    }

//    @Override
//    public List<PetTreatment> getPetTreatmentByPetTreatments(int vetId) {
//        return repository.;
//    }


}

